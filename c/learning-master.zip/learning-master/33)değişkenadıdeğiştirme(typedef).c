#include <stdio.h>

int main() {

	typedef int tamsayi;

	tamsayi a;
	a = 2;

	tamsayi b, c;
	b = 8;
	c = 11;

	tamsayi d = 7;

	printf("%d %d %d %d", a, b, c, d);

	return 0;
}
