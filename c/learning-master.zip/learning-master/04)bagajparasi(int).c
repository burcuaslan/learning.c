#include <stdio.h>
#include <stdlib.h>

int main() {

	int bagajsinir, bagaj, elsinir, el, fazlakilo, fazlakilo1, top, odeme;
	bagajsinir = 15;
	elsinir = 8;
	bagaj = 18;
	el = 9;
	fazlakilo = bagaj - bagajsinir;
	fazlakilo1 = el - elsinir;
	top = fazlakilo + fazlakilo1;
	odeme = top * 5;

	printf("Odeme: %d", odeme);

	return 0;
}
