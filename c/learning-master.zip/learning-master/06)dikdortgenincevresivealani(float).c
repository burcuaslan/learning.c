#include <stdio.h>
#include <stdlib.h>

int main() {

	float kisak, uzunk, cevre, alan;
	
	kisak = 5.15;
	uzunk = 13.75;

	cevre = 2 * kisak + 2 * uzunk;
	alan = kisak * uzunk;

	printf("Dikdortgenin Cevresi: %f\n", cevre);
	printf("Dikdortgenin Alani: %f", alan);

	return 0;
}
