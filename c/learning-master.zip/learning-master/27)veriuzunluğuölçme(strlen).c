#include <stdio.h>

int main() {

	char bilgi[50] = "Turkiye'nin baskenti Ankara''dir.";

	printf("%d", strlen(bilgi));

	return 0;
}
