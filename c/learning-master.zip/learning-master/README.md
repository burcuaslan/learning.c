# learning.c
Since first code..
