#include <stdio.h>
#include <stdlib.h>

int main() {

	float maas, zam, yenimaas;

	printf("Anlik maasinizi giriniz: ");
	scanf("%f", &maas);

	printf("Zam oranini giriniz: ");
	scanf("%f", &zam);

	yenimaas = maas + maas * zam;
	printf("Yeni maasiniz: %f", yenimaas);


	return 0;
}
