#include <stdio.h>

int main() {

	char bilgi[30];

	printf("Bilgiyi giriniz: ");
	gets(bilgi);
	printf("\nGirdiginiz bilgi: ");
	puts(bilgi);

	return 0;
}
